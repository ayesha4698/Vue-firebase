import numpy as np
import math
import cv2
from scipy.signal import convolve2d
import matplotlib.pyplot as plt

#########################################################
###    Part A: Image Processing Functions
######################################################### 

# TODO:PA2 Fill in this function
def normalizeImage(cvImage, minIn, maxIn, minOut, maxOut):
	'''
	Take image and map its values linearly from [min_in, max_in]
	to [min_out, max_out]. Assume the image does not contain 
	values outside of the [min_in, max_in] range.
	
	Parameters:
		cvImage - a (m x n) or (m x n x 3) image.
		minIn - the minimum of the input range
		maxIn - the maximum of the input range
		minOut - the minimum of the output range
		maxOut - the maximum of the output range
		
	Return:
		renormalized - the linearly rescaled version of cvImage.
	'''
	raise NotImplementedError

# TODO:PA2 Fill in this function
def getDisplayGradient(gradientImage):
	'''
	Use the normalizeImage function to map a 2d gradient with one
	or more channels such that where the gradient is zero, the image
	has 50% percent brightness. Brightness should be a linear function 
	of the input pixel value. You should not clamp, and 
	the output pixels should not fall outside of the range of the uint8 
	datatype.
	
	Parameters:
		gradientImage - a per-pixel or per-pixel-channel gradient array
						either (m x n) or (m x n x 3). May have any 
						numerical datatype.
	
	Return:
		displayGrad - a rescaled image array with a uint8 datatype.
	'''
	raise NotImplementedError

# TODO:PA2 Fill in this function
def takeXGradient(cvImage):
	'''
	Compute the x-derivative of the input image with an appropriate
	Sobel implementation. Should return an array made of floating 
	point numbers.
	
	Parameters:
		cvImage - an (m x n) or (m x n x 3) image
		
	Return:
		xGrad - the derivative of cvImage at each position w.r.t. the x axis.
	
	'''
	raise NotImplementedError
	
# TODO:PA2 Fill in this function
def takeYGradient(cvImage):
	'''
	Compute the y-derivative of the input image with an appropriate
	Sobel implementation. Should return an array made of floating 
	point numbers.
	
	Parameters:
		cvImage - an (m x n) or (m x n x 3) image
		
	Return:
		yGrad - the derivative of cvImage at each position w.r.t. the y axis.
	'''
	raise NotImplementedError
	
# TODO:PA2 Fill in this function
def takeGradientMag(cvImage):
	'''
	Compute the gradient magnitude of the input image for each 
	pixel in the image. 
	
	Parameters:
		cvImage - an (m x n) or (m x n x 3) image
		
	Return:
		gradMag - the magnitude of the 2D gradient of cvImage. 
				  if multiple channels, handle each channel seperately.
	'''
	raise NotImplementedError


#########################################################
###    Part B: k-Means Segmentation Functions
######################################################### 

# TODO:PA2 Fill in this function
def computeDistance(X, C):
	'''
	Compute each pairwise squared distance between elements
	of X and C using Euclidean metric. Do not take squared root

	Parameters:
		X - feature matrix (n x d)
		C - centroid matrix (m x d)

	Returns:
		dist - distance matrix m x n)
	'''      
	raise NotImplementedError

# TODO:PA2 Fill in this function
def getFeats(img):
	'''
	Compute and return feature vectors for each pixel in the image. 

	Normalize the x and y coordinates to the range [0, 1). 
	Normalize each RGB value in the image by the maximum value in any channel. 

	Note: do not use nested for loops to iterate through the image!
	Note: origin (0, 0) is top left

	Parameters:
		img - Input image (m x n x 3)

	Returns:
		feats - Array of feature vectors (m x n x 5)
	'''
	raise NotImplementedError

def runKmeans(feats, k, max_iter = 100): 
	'''
	Find a locally optimal clustering for the k-Means problem.

	Parameters:
		feats - array of points to cluster (n x d)
		k - number of clusters to create
		max_iter - number of iterations of the algorithm to run

	Returns:
		labels - array of labels (n)
	'''
	np.random.seed(11)
	idx = np.random.choice(feats.shape[0], k)
	centroids = feats[idx,:]
	for i in range(max_iter):
		distances = computeDistance(feats, centroids)
		mindist = np.min(distances, axis=0)
		labels = np.argmin(distances, axis=0)
		for j in range(k):
			if np.sum(labels==j) > 0:
				centroids[j,:] = np.mean(feats[labels==j,:], axis=0)
			else:
				idx = np.random.choice(feats.shape[0])
				labels[idx] = j
				centroids[j,:] = feats[idx,:]
	return labels

def segmentKmeans(img, num):
	'''
	Execute a color-based k-means segmentation 
	'''
	feats = getFeats(img)
	segments = runKmeans(feats.reshape((-1, feats.shape[2])),num, 100)
	return segments.reshape((img.shape[0], img.shape[1]))


#########################################################
###    Part C: Texture Based Edge Detection
######################################################### 
# TODO:PA2 Fill in this function
def getOrientedFilter(f, theta, size=11):
	'''
		Return a oriented filter of size `size` oriented at angle theta. 

		Parameters:
			f - function that takes in vectors of x, y coordinates
				and returns a gaussian filter
			theta - angle (radians) needed to generate x and y
			size - size of the filter

		Returns:
			gaussFilter - a (size, size) array
	'''    
	raise NotImplementedError

# TODO:PA2 Fill in this function
def getDoG(x, y, sigma_1=0.7, sigma_2=2):
	'''
		Return a Difference of Gaussians filter value for each element in zip(x, y).

		Parameters:
			x - array of x coordinates (n)
			y - array of y coordinates (n)
			sigma_1 - standard deviation of the first filter
			sigma_2 - standard deviation of the second filter
		Returns:
			diff - array of filter values (n)
	'''    
	raise NotImplementedError

def getGaussDeriv(x, y, sigma_x=0.7, sigma_y=2):
	return -x*np.exp(-(x*x/(2*sigma_x*sigma_x) + y*y/(2*sigma_y*sigma_y)))

def getGauss2Deriv(x, y, sigma_x=0.7, sigma_y=2):
	ygauss = np.exp(-y*y/(2*sigma_y*sigma_y))
	xgauss = np.exp(-x*x/(2*sigma_x*sigma_x))
	val = xgauss*ygauss*(x*x/(sigma_x**4) - 1/(sigma_x*sigma_x))
	return val

def getGaussian(x,y,sigma=1):
	gauss = np.exp(-(x*x+y*y)/(2*sigma*sigma))/(2*np.pi*sigma*sigma)
	return gauss

def getFilterBank():
	filters = []
	for theta in np.arange(0, np.pi, np.pi/8):
		filters.append(getOrientedFilter(getGaussDeriv, theta))
		filters.append(getOrientedFilter(getGauss2Deriv, theta))
	filters.append(getOrientedFilter(getDoG, 0))
	return filters


# TODO:PA2 Fill in this function
def getTextons(img, vocab_size=100):
	'''
		Compute textons and assign each pixel to a texton.

		Preprocess each channel by normalizing (divide by 255) and convolving with gaussian.

		Each pixel is associated with a feature vector of 3*len(filter_bank) containing
		one entry for each channel for each filter such that
		[R's filters, B's filters, G's filters]. Note, this is not the feature vector
		returned by getFeats in Part B.

		These vectors are then clustered using K-means and converted into one-hot labels
		for each pixel.

		Parameters:
			img - input image (n x m x 3)
			vocab_size - texton dimension
		Returns:
			labels - one hot labels for each pixel in the image (n x m x vocab_size)
			features - numpy array of features (n*m, 3 * len(filter_bank))
	'''

	gaussian = getOrientedFilter(getGaussian,0)

	filter_bank = getFilterBank()
	feats = []

	# TODO:PA2 Fill in this part
	raise NotImplementedError	
	# END: PA2

	labels = runKmeans(feats, vocab_size, 500)
	onehotlabels = np.zeros((labels.shape[0], vocab_size))
	for i in range(labels.shape[0]):
		onehotlabels[i,labels[i]] = 1

	return onehotlabels.reshape((img.shape[0], img.shape[1],-1)), feats



# TODO:PA2 Fill in this function
def getMasks(theta,size):
	'''
		Create two filters (size x size) to partition an image into two halves 
		based on orientation (theta).

		For theta = pi/4 and size = 5, the first filter returned would be:
		array([[False, False, False, False, False],
			   [ True, False, False, False, False],
			   [ True,  True, False, False, False],
			   [ True,  True,  True, False, False],
			   [ True,  True,  True,  True, False]], dtype=bool)

		Parameters:
			theta - the angle of the line across which to divide
			size - the size of the filter to produce
		Returns:
			mask_1 - the filter with True values for the left side of the image
			mask_2 - the filter with True values for the right side of the image


	'''
	raise NotImplementedError

# TODO:PA2 Fill in this function
def computeTextureGradient(img, vocab_size=100, r=10):
	'''
		Use getTextons to get the one-hot labels for img and flatten to a
		1D array of pixels' one-hot vectors.

		Generate masks for thetas from [0, pi] with step size pi/4.

		Compute differences of histograms in oriented half-discs of width r.

		Parameters:
			img - (m x n x 3) image
			vocab_size - how many textons to split into
			r - width of oriented half-discs
		Returns:
			G - (n x m x 4) where 4 is len(theta)


	'''  
	raise NotImplementedError
